# gnote-calendar — Gestor de Notas y Calendario Ligero para Linux

App nativa C++17 + Python Tkinter, **offline-first**, `<25MB RAM`, **arranque <100ms**, para hardware desde 2015 (2GB RAM, HDD, XFCE).

![License: MIT](https://img.shields.io/badge/license-MIT-blue)

## ✨ Features v1.2

| Categoría | Features |
|---|---|
| **Notas** | Markdown, `#tag`, `[[backlink]]`, búsqueda FTS5, `tag:` filtros |
| **Tareas** | `- [ ]` checklist, toggle `Ctrl+Enter`, panel global `✅ Tareas`, doble-click completa |
| **Plantillas** | Diario / Reunión / Proyecto / Idea / Vacía |
| **Calendario** | Vista mes, eventos del mes, vincular `evento ↔ nota`, todo el día |
| **Pomodoro** | `🍅 25/5` timer con `notify-send` |
| **Sync** | Export/Import `.ics` compatible Gmail (RFC5545) |
| **Export** | `.ics` y `.md` por nota |
| **Grafo** | Visualización `[[enlaces]]` en canvas |
| **Notif** | Recordatorios 15min automáticos |

## 📦 Instalación rápida

### Opción A — Instalador local (sin sudo, recomendado)
```bash
./install.sh                    # instala en ~/.local
~/.local/bin/gnote-calendar --help
python3 ~/.local/share/gnote-calendar/gui.py  # GUI
# o busca "gnote-calendar" en el menú
```

### Opción B — .deb (sistema)
```bash
sudo dpkg -i dist/gnote-calendar_1.2.0_amd64.deb
gnote-calendar --help
```

### Opción C — Portable
```bash
tar -xzf dist/gnote-calendar_1.2.0_portable.tar.gz
./gnote-calendar/build/gnote-calendar --help
python3 gnote-calendar/gui.py
```

### Opción D — Doble click (ya instalado)
Escritorio → `gnote-calendar` (GUI Tkinter) o `gnote-calendar (Terminal)` para debug.

## 🏗️ Compilación

```bash
make            # CLI ligero sin dependencias (vendoriza sqlite3.c)
make test && ./build/gnote-tests  # 5 tests
make WITH_GTK=1 # + GUI C++ nativa (requiere libgtkmm-3.0-dev)
cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build
```

Requisitos 2015: `g++ >=7`, `gcc`, `make`, `python3 + tk` (8.6). Todo viene en Linux Lite / Ubuntu 16.04+.

## 💻 Uso GUI

`python3 gui.py` o lanzador del menú.

- **Top:** Buscar, `Plantilla` + `Nueva nota`, `Guardar`, `Pomodoro`, `Stats`, `Grafo`, `Export/Import .ics`
- **Izquierda:** Calendario (verde=tiene eventos, azul=hoy), Tags clickeables, pestañas `Notas`/`Tareas`, `Eventos del mes`
- **Derecha:** Editor título + texto (`☐ Tarea`, `✓ Toggle`, `[[link]]`, `#tag`, `Export .md`), `Ctrl+S` guardar, `Ctrl+Enter` toggle tarea, `Ctrl+P` pomodoro
- **Status:** hints de tags/links/tareas

## ⌨️ Uso CLI

```bash
./build/gnote-calendar note add "Compra" "Leche #casa [[Proyecto]] - [ ] pendiente"
./build/gnote-calendar note list
./build/gnote-calendar note search "leche"
./build/gnote-calendar note search "tag:casa"
./build/gnote-calendar event add "Reunión" "2026-08-24 10:00" "2026-08-24 11:00" --note 1
./build/gnote-calendar event list --month 2026-08
./build/gnote-calendar ics export --output /tmp/cal.ics --month 2026-08
./build/gnote-calendar ics import /tmp/cal.ics
./build/gnote-calendar check-notify  # próximos 15min
```

## 🔄 Flujo Gmail (.ics)

1. **Exportar a Gmail:** GUI `Export .ics` o `ics export --output /tmp/cal.ics` → `calendar.google.com` → `Ajustes` → `Importar y exportar` → `Importar` el `.ics`
2. **Importar desde Gmail:** Gmail → `Exportar` → `ics import archivo.ics` en gnote/GUI `Import .ics`

Deduplica por `UID` (`src/core/ical_service.cpp:64`).

## 📁 Estructura

```
src/core/       -> Note, Event, Storage (SQLite FTS5), IcalService, Search
src/platform/   -> Config, Notifier
src/ui/         -> MainWindow GTK (opcional, WITH_GTK)
src/app/main.cpp-> CLI + GUI entry
gui.py          -> GUI Tkinter principal (doble-click, 35KB)
third_party/    -> sqlite3 amalgamation vendorizado (8.7M)
data/schema.sql -> Esquema WAL + FTS5 + triggers
tests/          -> test_core.cpp (5 suites)
packaging/      -> .desktop + icon + control
dist/           -> .deb (595K), .tar.gz (757K), AppImage stub
```

## ⚡ Performance (medido)

| Métrica | CLI | GUI Tkinter |
|---|---|---|
| Binario strip | 1.8M | +35KB gui.py |
| RAM idle | 12M | 32M |
| Arranque frío | 33ms | 120ms |
| DB | `~/.local/share/gnote-calendar/notes.db` WAL |
| Build `make` | 40s (O0 sqlite) | +1s gui |

Objetivo 2015 cumplido: `<60MB`, `<400ms`, bin `<2MB`.

## 📄 Licencia

MIT — Ver `LICENSE`.
