# gnote-calendar - Gestor de Notas y Calendario Ligero para Linux

App nativa C++17, offline-first, <60MB RAM, arranque <400ms. Diseñada para hardware desde 2015.

## Stack
- **Core:** C++17 + SQLite3 (vendorizado) + FTS5
- **UI:** GTK3 + gtkmm 3.0 (opcional, fallback CLI)
- **ICS:** Parser propio sin dependencias (compatible Gmail)
- **Build:** Makefile (sin dependencias) + CMake opcional

## Estructura
```
src/core/       -> Lógica pura (Note, Event, Storage, IcalService, Search)
src/platform/   -> Config, Notifier (libnotify opcional)
src/ui/         -> MainWindow GTK (compila solo si gtkmm instalado)
src/app/main.cpp-> Entry point CLI + GUI
third_party/    -> sqlite3 amalgamation vendorizado
data/schema.sql -> Esquema DB
tests/          -> Tests Catch2-like minimal
```

## Compilación Rápida (sin instalar nada)
```bash
make            # compila core + CLI
./build/gnote-calendar --help
make test && ./build/gnote-tests
```

## Con GTK (opcional, para GUI)
```bash
sudo apt install libgtkmm-3.0-dev libsqlite3-dev libical-dev  # solo si tienes sudo
make WITH_GTK=1
# o con CMake:
cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build
```

## Uso CLI (siempre disponible, ultra-ligero)
```bash
./build/gnote-calendar note add "Compra" "Leche y pan #casa"
./build/gnote-calendar note list
./build/gnote-calendar note search "leche"
./build/gnote-calendar event add "Reunión" "2026-08-24 10:00" "2026-08-24 11:00" --note 1
./build/gnote-calendar event list --month 2026-08
./build/gnote-calendar ics export --output /tmp/cal.ics --month 2026-08
./build/gnote-calendar ics import /tmp/cal.ics  # desde Gmail
```

## Flujo Gmail (.ics)
1. En gnote: `ics export` -> sube a calendar.google.com -> Importar
2. En Gmail: Ajustes -> Importar y exportar -> Exportar -> `ics import archivo.ics` en gnote

## Performance Objetivo
- RAM idle: <35MB (CLI), <60MB (GUI)
- Binario: <2MB (CLI), <9MB (GUI)
- DB: SQLite single file `~/.local/share/gnote-calendar/notes.db`
